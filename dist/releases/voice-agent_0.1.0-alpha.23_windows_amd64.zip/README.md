# Voice Agent

**Cross-platform, local-first voice input for AI coding tools.** Speak a prompt, transcribe it locally, and use the text in your coding assistant — without sending audio to a cloud service.

> **v0.1 Alpha 12 · first supported installation path: macOS.** Voice Agent is designed for macOS, Linux and Windows. The first end-to-end setup targets Apple Silicon and Intel Macs with OpenCode v2. Linux/Windows release binaries exist, but their installation workflows and end-to-end integration are not yet validated. Codex CLI and Claude Code adapters are planned.

## What it does

1. Press **Command+Shift+R (⌘⇧R)** (if your terminal forwards it), or invoke `/r`, to start recording; trigger it again to stop.
2. The footer shows **● REC** while recording and **VOICE: TRANSCRIBING…** while whisper.cpp recognizes speech locally.
3. Review the transcription in a confirmation dialog: **Enter** submits to the active OpenCode session; **Esc** cancels. Without an active session, the adapter offers a clipboard fallback.

**Current limitation:** the transcript is submitted to the active session after confirmation, not inserted into the editable composer. The TUI integration has not yet been validated on a physical Mac.

## First integration: OpenCode v2 (macOS)

This is the **first working target**, not the only platform or coding tool Voice Agent is designed for. Linux/Windows setup and Codex CLI/Claude Code integrations will have their own guides as they become validated.

### 1. Install

**Prerequisites:** macOS (Apple Silicon or Intel), [Homebrew](https://brew.sh/), Node.js 20+, OpenCode v2, and microphone permission. The packaged Go binary does **not** require Go to be installed.

Download and unpack the Alpha 12 archive. In Terminal, change into the extracted project directory and run:

```sh
brew install sox whisper-cpp
node scripts/install-macos.mjs
$HOME/.local/bin/voice-agent doctor
```

The installer selects the macOS binary, registers the OpenCode TUI plugin, downloads and SHA256-verifies the **Whisper Base Multilingual** model (~148 MB), and stores its path automatically. You do **not** need to set `WHISPER_MODEL`. The initial download requires internet; speech recognition subsequently runs locally.

### Upgrade from Alpha 8, 9, or later

To upgrade an existing installation, **download and extract the new release** and run its updater from the extracted directory:

```sh
node scripts/update.mjs
$HOME/.local/bin/voice-agent doctor
```

The updater detects the installed plugin version, upgrades both the **Go binary and OpenCode adapter**, and retains `cli.json` settings and the downloaded Whisper model. It checks the binary archive against bundled SHA256 checksums and restores the previous binary, plugin and OpenCode configuration if installation fails. Restart OpenCode after updating. Running it again at the same version makes no changes. Downgrades are refused unless `--allow-downgrade` is provided.

**Alpha 8 → Alpha 12:** run the command from the **Alpha 12** extracted directory; Alpha 8 itself did not ship with the updater. No uninstall is required. This is a **local-release updater**: it does not yet discover or download new releases automatically.

For a nonstandard installation, pass `--config-dir` and `--bin-dir`. Do not run with `sudo`.

### 2. Start OpenCode and check the plugin

```sh
opencode
```

In the OpenCode command input, run `/voice-doctor`. This should show diagnostic information about the voice binary, SoX, Whisper and the model. If the command does not appear, inspect the `plugins` entry in `~/.config/opencode/cli.json` and the [macOS troubleshooting guide](docs/MACOS.md). The plugin's actual loading in a real OpenCode v2 TUI has **not yet been validated** on a physical Mac.

### 3. Your first voice prompt

1. Press **Command+Shift+R (⌘⇧R)** (or invoke **`/r`**) to begin. Look for **● REC** in the footer.
2. Say something like “Explain what this Python function does and suggest improvements.” Press the shortcut again to stop.
3. Wait for **VOICE: TRANSCRIBING…** to disappear and review the text in the confirmation dialog.
4. Press **Enter** to send it to the active OpenCode session, or **Esc** to cancel. Without an active session, use the clipboard fallback.

> **Alpha limitation:** Enter sends the confirmed text directly to the active session; it does not populate the editable composer. This workflow still needs verification in a running OpenCode v2 TUI on macOS.

### Commands and troubleshooting

| Command | What it does |
| --- | --- |
| `/voice-doctor` | Show status of recording/transcription dependencies |
| `/r` | Toggle start/stop recording; show a live status indicator and a preview dialog; Enter sends to active session |

If recording fails, check **System Settings → Privacy & Security → Microphone** and permit your terminal application. If `doctor` cannot find SoX or Whisper, ensure your Homebrew installation is on `PATH`. For more details, see [macOS setup and troubleshooting](docs/MACOS.md).

**Future integration guides:** Codex CLI and Claude Code (planned); Linux and Windows platform instructions will follow validation. The [architecture](docs/adr/0004-cross-platform-boundaries.md) keeps host adapters and platform-dependent implementations separate.

## How it works

```text
OpenCode v2 TUI
   │ /r
   ▼
TypeScript adapter (adapters/opencode/)
   │ JSON-RPC 2.0 over local stdio
   ▼
Go core (cmd/, internal/)
   ├── SoX           → microphone recording
   ├── whisper.cpp   → offline speech-to-text
   └── Piper         → optional text-to-speech
   │
   ▼
Transcript → preview → Enter to submit (or Esc to cancel)
```

The **Go core** does not depend on OpenCode or macOS. Editor-specific adapters own host UI behavior; platform-specific components own microphone capture, dependency discovery, installation and filesystem locations. Audio and transcription run locally; no background server or cloud account is required. Piper is optional and not part of the default quick start. See [platform architecture](docs/adr/0004-cross-platform-boundaries.md).

## macOS paths (first iteration)

| Location | What it stores |
| --- | --- |
| `~/.local/bin/voice-agent` | Go executable |
| `~/.config/opencode/cli.json` | OpenCode TUI plugin registration |
| `~/.config/opencode/voice-agent-plugin/` | Installed TypeScript adapter |
| `~/Library/Application Support/VoiceAgent/` | `config.json` and Whisper model |

To use a different existing model, set `WHISPER_MODEL` to its absolute path **before running the installer**. For installation without downloading, use `node scripts/install-macos.mjs --offline` (an existing model is then required for transcription).

## Project layout

- `cmd/`, `internal/` — Go CLI, voice engine and JSON-RPC transport.
- `adapters/opencode/` — OpenCode v2 TUI integration.
- `scripts/` — installers, model management and release tooling.
- `docs/MACOS.md` — macOS setup and troubleshooting (first supported installation path).
- `docs/adr/0004-cross-platform-boundaries.md` — cross-platform boundaries and rollout gates.
- `docs/INSTALL.md` — other installation and development details.
- `docs/adr/` — architecture decisions.

## Status and scope

**Implemented:** local recording/transcription pipeline, Go CLI, diagnostics, macOS installer, model download with checksum verification, OpenCode adapter source, recording status and confirmation flow.

**Not yet validated:** actual OpenCode v2 TUI integration on macOS, microphone/device operation on a physical Mac, and Linux/Windows end-to-end installation. **Not yet implemented:** editable composer insertion, persistent transcript storage, Codex CLI/Claude Code adapters.

**Roadmap:** stabilize macOS + OpenCode first; then test Linux and Windows platform integrations; then add Codex CLI and Claude Code adapters. This is a delivery order, **not** a macOS-only product architecture.

The project is a new implementation inspired by [renjfk/opencode-voice](https://github.com/renjfk/opencode-voice), not a source-code fork.

## Keyboard shortcuts (OpenCode v2)

Voice Agent registers one action (`voice-agent.record`) and slash command **`/r`**.
The installer adds the following platform-specific default to `~/.config/opencode/cli.json` under `keybinds`, **without overwriting an existing value**:

| Operating system | Default | OpenCode key syntax |
| --- | --- | --- |
| macOS | Command + Shift + R (⌘⇧R) | `super+shift+r` |
| Linux | Ctrl + Alt + R | `ctrl+alt+r` |
| Windows | Ctrl + Shift + R | `ctrl+shift+r` |

For example, macOS:

```json
{
  "keybinds": {
    "voice-agent.record": "super+shift+r"
  }
}
```

To customize the shortcut, edit **only** `keybinds.voice-agent.record` in your existing CLI configuration, not the whole file. The installer and updater retain custom values, including `"none"` to disable the binding. The `voice-agent.record` action uses the same start/stop recording logic as `/r`. `● REC` is red during recording.

**iTerm2 caveat:** Command combinations often do not reach terminal applications. If ⌘⇧R is intercepted, configure an iTerm2 key mapping to **Send Hex Code** `0x07` (Ctrl+G) and explicitly set `"voice-agent.record": "ctrl+g"` in `cli.json`, or use `/r`. Note Ctrl+G may collide with OpenCode's `session.first` command; override that binding if necessary. The plugin no longer hardcodes any key bindings, and real iTerm2 / OpenCode 2.1.4 integration still needs on-device validation.

### Recording feedback and confirmation

The red `● REC · /r to stop` marker appears while recording. During transcription it changes to `VOICE: TRANSCRIBING…`. After transcription, the recognized text is automatically inserted into the OpenCode input draft. Edit it there and press Enter to send.

### Developer validation

Install development dependencies in `adapters/opencode` (`npm install`) and run `node scripts/check-plugin-syntax.mjs`. The release script checks TS/TSX syntax before packaging.

### Voice prompt delivery (Alpha 20)

After transcription, Voice Agent automatically appends recognized text to the OpenCode input draft via `client.focused OpenTUI composer (insertText)({ body: { text } })`. No session ID is required and nothing is sent to the agent until you press Enter yourself. Existing draft text is preserved by the append operation. If the method is unavailable (possible on OpenCode v2), Voice Agent displays a clear error with the transcription; it does not silently copy or submit anything. This integration requires an on-device test with OpenCode v2.1.4.

### Hotkey diagnostics (Alpha 20)

Run **`/hotkey_record_debug`** inside OpenCode. The dialog reports OS/terminal identity, the `voice-agent.record` binding from `cli.json`, and the timestamp of the last recording-handler invocation **in the current plugin instance**. To isolate a failure, run `/r`, inspect the timestamp, try the hotkey, then run `/hotkey_record_debug` again. An unchanged timestamp means the recording handler did not receive the event. This cannot identify which macOS application or iTerm2/OpenCode component intercepted the shortcut; use iTerm2 Key Mappings to narrow it down. No global keyboard monitoring or extra macOS permissions are used.

### Alpha 23 — OpenTUI composer compatibility

The focused OpenTUI editor exposes its content through the `plainText` property.
The voice transcription insertion now validates `insertText` and `plainText`, with
`getText()` supported as a compatibility fallback. It does not auto-send messages.

### STT language and translation (Alpha 23)

Edit `~/Library/Application Support/VoiceAgent/config.json` on macOS and preserve your existing `stt.modelPath`:

```json
{ "stt": { "modelPath": "/existing/path/ggml-base.bin", "language": "ru", "translate": false } }
```

`language` defaults to `auto`; `translate` defaults to `false`. The Go engine passes `-l <language>` to whisper.cpp and adds `-tr` only when `translate` is `true`. Restart OpenCode after editing.
